worlo Teams (Mac — lightweight launcher)
========================================
This zip is a small launcher. For the full native app (worlo W icon in your Dock),
download worlo-teams-mac.zip from GitHub Releases:
https://github.com/aethercous/flowix/releases/latest

To use this launcher:
1. Unzip anywhere.
2. Double-click "Open worlo Teams.command"
   (first time: right-click → Open if macOS blocks it)
3. worlo Teams opens in its own window.

Requires internet.
