worlo Teams (Mac)

1. Unzip this folder anywhere (e.g. Desktop).
2. Double-click "Open worlo Teams.command".
   First time only: if macOS blocks it, right-click the file > Open > Open.
   The app opens in its own window.

Need an invite code? Get one from the worlo dashboard.
