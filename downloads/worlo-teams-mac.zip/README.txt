worlo Teams (Mac)
=================
1. Unzip this folder anywhere (e.g. Applications or Desktop).
2. Double-click "Open worlo Teams.command".
   First time only: if macOS blocks it, right-click the file -> Open -> Open.
3. Your browser opens worlo Teams. Paste your WORLO invite code from the dashboard.

Prefer no download? Open https://flowix.space/teams-app/index.html in any browser.
Chat requires an internet connection.
