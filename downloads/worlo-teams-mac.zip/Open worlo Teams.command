#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null || true
FILE="file://${DIR}/teams-app/index.html"
open -a Safari "$FILE" 2>/dev/null || open "$FILE"
