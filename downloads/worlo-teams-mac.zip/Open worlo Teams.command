#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
FILE="file://${DIR}/teams-app/index.html"
open -a Safari "$FILE" 2>/dev/null || open "$FILE"
