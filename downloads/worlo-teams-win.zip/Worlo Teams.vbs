Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
sh.Run Chr(34) & dir & "\Worlo Teams.bat" & Chr(34), 0, False
