worlo Teams (Windows)

1. Unzip this folder anywhere (e.g. Desktop).
2. Double-click "Open worlo Teams.bat".
   The app opens in its own window.

Need an invite code? Get one from the worlo dashboard.
For the native installer (.exe) with a desktop icon, see
https://flowix.space/teams-app/download.html
