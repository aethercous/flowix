worlo Teams (Windows)

1. Unzip this folder anywhere (e.g. Desktop).
2. Double-click "Open worlo Teams.bat".
3. The app opens in your default browser.

Need an invite code? Get one from the worlo dashboard.
For the native installer (.exe), see https://flowix.space/teams-app/download.html
