worlo Teams portable
=====================
1. Unzip this folder anywhere.
2. Run "Open worlo Teams.bat".
3. Your browser opens worlo Teams - paste your WORLO invite code from the dashboard.

Chat requires an internet connection (Supabase).
