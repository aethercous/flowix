flowix Teams portable
=====================
1. Unzip this folder anywhere.
2. Run "Open flowix Teams.bat".
3. Your browser opens flowix Teams â€” paste your FLOWIX invite code from the dashboard.

Chat requires an internet connection (Supabase).