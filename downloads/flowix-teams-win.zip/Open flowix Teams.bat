@echo off
cd /d "%~dp0"
start "" "%~dp0teams-app\index.html"